# Animaciones de entrada en React (Framer Motion)

Instalación: `npm install framer-motion` (en proyectos nuevos el paquete se llama `motion` y se importa desde `motion/react`; usa el que ya tenga el proyecto).

## Constantes compartidas

```jsx
// motion.config.js
export const EASE = [0.22, 1, 0.36, 1];
export const DUR = 0.7;
export const DIST = 24;
export const STAGGER = 0.08;

export const fadeUp = {
  hidden: { opacity: 0, y: DIST },
  show: { opacity: 1, y: 0, transition: { duration: DUR, ease: EASE } },
};

export const container = {
  hidden: {},
  show: { transition: { staggerChildren: STAGGER } },
};
```

## Fade + slide up con stagger

```jsx
import { motion } from 'framer-motion';
import { container, fadeUp } from './motion.config';

export function Lista({ items }) {
  return (
    <motion.ul variants={container} initial="hidden" animate="show">
      {items.map((item) => (
        <motion.li key={item.id} variants={fadeUp}>
          {item.texto}
        </motion.li>
      ))}
    </motion.ul>
  );
}
```

## Blur-in

```jsx
const blurIn = {
  hidden: { opacity: 0, y: 16, filter: 'blur(10px)' },
  show: {
    opacity: 1,
    y: 0,
    filter: 'blur(0px)',
    transition: { duration: 0.8, ease: EASE },
  },
};

<motion.h1 variants={blurIn} initial="hidden" animate="show">
  Titular
</motion.h1>
```

## Reveal al hacer scroll (una sola vez)

```jsx
<motion.section
  initial={{ opacity: 0, y: DIST }}
  whileInView={{ opacity: 1, y: 0 }}
  viewport={{ once: true, amount: 0.2 }}
  transition={{ duration: DUR, ease: EASE }}
>
  Contenido
</motion.section>
```

## Máscara de texto (Revelado)

```jsx
export function TituloRevelado({ texto }) {
  return (
    <span style={{ display: 'block', overflow: 'hidden' }}>
      <motion.span
        style={{ display: 'inline-block' }}
        initial={{ y: '110%' }}
        animate={{ y: 0 }}
        transition={{ duration: 0.9, ease: EASE }}
      >
        {texto}
      </motion.span>
    </span>
  );
}
```

## Escala (Dinámico) y overshoot (Juguetón)

```jsx
// Dinámico
const scaleIn = {
  hidden: { opacity: 0, scale: 0.9 },
  show: { opacity: 1, scale: 1, transition: { duration: 0.6, ease: EASE } },
};

// Juguetón: spring
const bounceIn = {
  hidden: { opacity: 0, scale: 0.6, rotate: -4 },
  show: {
    opacity: 1,
    scale: 1,
    rotate: 0,
    transition: { type: 'spring', stiffness: 260, damping: 20 },
  },
};
```

## Reducir movimiento

```jsx
import { useReducedMotion } from 'framer-motion';

export function Tarjeta({ children }) {
  const reduce = useReducedMotion();
  const variants = reduce
    ? { hidden: { opacity: 0 }, show: { opacity: 1, transition: { duration: 0.3 } } }
    : fadeUp;

  return (
    <motion.div variants={variants} initial="hidden" animate="show">
      {children}
    </motion.div>
  );
}
```

## Reglas para React

- Define las variantes fuera del componente para no recrearlas en cada render.
- Usa `initial` y `animate` solo una vez por montaje; no los cambies en cada render.
- `whileInView` con `viewport={{ once: true }}` evita que la animación se repita al hacer scroll.
- Para listas largas, usa `staggerChildren` con poca cantidad de hijos animados o aplica `whileInView` a cada tarjeta.
