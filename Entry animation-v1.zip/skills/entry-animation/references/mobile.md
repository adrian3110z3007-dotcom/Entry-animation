# Animaciones de entrada en apps móviles

## Tabla de contenidos
1. Android (Jetpack Compose)
2. iOS (SwiftUI)
3. Flutter
4. React Native (Reanimated)
5. Reducir movimiento en cada plataforma

## 1. Android (Jetpack Compose)

Entrada de una tarjeta con fade + slide up y spring suave:

```kotlin
@Composable
fun EntradaTarjeta(delayMs: Int = 0, content: @Composable () -> Unit) {
    var visible by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        delay(delayMs.toLong())
        visible = true
    }

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(700, easing = CubicBezierEasing(0.22f, 1f, 0.36f, 1f))) +
                slideInVertically(
                    animationSpec = spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessLow),
                    initialOffsetY = { it / 6 }
                )
    ) {
        content()
    }
}
```

Stagger de lista:

```kotlin
LazyColumn {
    itemsIndexed(items) { index, item ->
        EntradaTarjeta(delayMs = (index.coerceAtMost(8)) * 80) {
            TarjetaItem(item)
        }
    }
}
```

Escala para estilo Dinámico:

```kotlin
AnimatedVisibility(
    visible = visible,
    enter = fadeIn(tween(600)) + scaleIn(initialScale = 0.9f, animationSpec = tween(600))
) { content() }
```

## 2. iOS (SwiftUI)

Entrada con fade, desplazamiento y spring:

```swift
struct EntradaModifier: ViewModifier {
    let delay: Double
    @State private var visible = false

    func body(content: Content) -> some View {
        content
            .opacity(visible ? 1 : 0)
            .offset(y: visible ? 0 : 24)
            .onAppear {
                withAnimation(.spring(response: 0.6, dampingFraction: 0.85).delay(delay)) {
                    visible = true
                }
            }
    }
}

extension View {
    func entrada(delay: Double = 0) -> some View {
        modifier(EntradaModifier(delay: delay))
    }
}
```

Uso con stagger:

```swift
ForEach(Array(items.enumerated()), id: \.offset) { index, item in
    TarjetaItem(item: item)
        .entrada(delay: Double(min(index, 8)) * 0.08)
}
```

Blur-in (iOS 17 o superior):

```swift
.blur(radius: visible ? 0 : 10)
.opacity(visible ? 1 : 0)
```

## 3. Flutter

```dart
class EntradaAnimada extends StatefulWidget {
  final Widget child;
  final Duration delay;
  const EntradaAnimada({super.key, required this.child, this.delay = Duration.zero});

  @override
  State<EntradaAnimada> createState() => _EntradaAnimadaState();
}

class _EntradaAnimadaState extends State<EntradaAnimada>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 700),
  );
  late final Animation<double> _curve =
      CurvedAnimation(parent: _c, curve: const Cubic(0.22, 1, 0.36, 1));

  @override
  void initState() {
    super.initState();
    Future.delayed(widget.delay, () {
      if (mounted) _c.forward();
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _curve,
      child: SlideTransition(
        position: Tween(begin: const Offset(0, 0.08), end: Offset.zero).animate(_curve),
        child: widget.child,
      ),
    );
  }
}
```

Importante: siempre llama a `dispose()` del controller para evitar fugas de memoria.

## 4. React Native (Reanimated)

```jsx
import Animated, { FadeInUp } from 'react-native-reanimated';

<Animated.View entering={FadeInUp.duration(700).delay(index * 80)}>
  <Tarjeta item={item} />
</Animated.View>
```

Para overshoot con spring:

```jsx
import { FadeInDown, ZoomIn } from 'react-native-reanimated';

<Animated.View entering={ZoomIn.springify().damping(14)}>
  ...
</Animated.View>
```

## 5. Reducir movimiento en cada plataforma

- **Android**: consulta `Settings.Global.ANIMATOR_DURATION_SCALE`. Si es 0, desactiva las animaciones decorativas y muestra el contenido directamente. En Compose, puedes usar `Modifier` con `if` para omitir la animación.
- **iOS**: revisa `UIAccessibility.isReduceMotionEnabled` o en SwiftUI `@Environment(\.accessibilityReduceMotion)`. Si está activo, reemplaza el desplazamiento por un simple fade con `.easeIn(duration: 0.2)`.
- **Flutter**: revisa `MediaQuery.of(context).disableAnimations` y `MediaQuery.of(context).accessibleNavigation`. Si es verdadero, muestra el widget sin controlador.
- **React Native**: usa `AccessibilityInfo.isReduceMotionEnabled()` para decidir si aplicas `entering`.

## Reglas para apps

- Usa 60 fps como mínimo: anima solo transform y opacidad; evita re-layouts durante la animación.
- No bloquees la interacción mientras corre la entrada: el usuario debe poder tocar aunque el elemento aún se esté moviendo.
- En pantallas que se abren a menudo, reduce la duración a 300–400 ms para no cansar.
- Entradas de pantallas completas (navegación) pertenecen al sistema de navegación de la plataforma; no las reemplaces salvo que se pida explícitamente.
