---
name: entry-animation
description: Genera animaciones de entrada (entrance animations) elegantes, fluidas y con buen rendimiento para páginas web y apps. Úsala siempre que el usuario pida animar la aparición de elementos, secciones, textos, tarjetas, listas, héroes, modales, pantallas o componentes, aunque no use la palabra "animación" (por ejemplo, "que los elementos aparezcan suavemente", "efecto de entrada", "que cargue con estilo", "fade in", "reveal on scroll", "stagger", "micro-interacciones de carga", "que la landing se vea premium"). Cubre CSS puro, Tailwind, JavaScript vanilla, React con Framer Motion, y apps móviles (Android Compose, SwiftUI, Flutter, React Native). Si el pedido incluye la palabra "web", "app", "landing", "dashboard", "pantalla de bienvenida" o "splash", también aplica.
---

# Animaciones de entrada

Esta skill produce animaciones de entrada que se sienten **estilosas, fluidas y sin tirones**. El objetivo no es "que se mueva", sino que el movimiento guíe la vista, dé jerarquía y transmita calidad.

## Flujo de trabajo

1. **Identificar el entorno.** Pregunta solo si no es evidente: ¿web (HTML/CSS/JS, React, Vue), o app (Android, iOS, Flutter, React Native)? Si hay código existente, respeta su stack (librerías ya presentes, convenciones de nombres, Tailwind o CSS modules).
2. **Elegir un estilo** (ver tabla). Si el usuario no lo especifica, usa "Elegante" por defecto.
3. **Aplicar el sistema de movimiento** (duraciones, easing y stagger de abajo). No inventes curvas ni tiempos aleatorios.
4. **Escribir el código** en el formato del entorno. Incluye siempre soporte de `prefers-reduced-motion` (web) o su equivalente en la plataforma (app).
5. **Entregar** con una explicación corta: qué estilo usaste, cómo ajustar la velocidad (una variable o constante), y dónde aplicarlo.

## Estilos disponibles

| Estilo | Carácter | Uso ideal | Recorrido típico |
|---|---|---|---|
| **Sutil** | Discreto, casi invisible | Dashboards, apps de productividad, documentación | Fade + desplazamiento de 8–12px |
| **Elegante** (por defecto) | Suave, editorial | Landings, portafolios, marcas premium | Fade + 24px arriba + leve blur que se disuelve |
| **Dinámico** | Energía, impacto | Producto nuevo, eventos, campañas | Escala desde 0.9 + stagger más marcado |
| **Revelado** | Máscara o recorte | Titulares grandes, hero sections | Texto que sube desde una máscara (overflow hidden) |
| **Juguetón** | Rebote con personalidad | Apps infantiles, marcas jóvenes, juegos | Overshoot con spring, rotación mínima |

## Sistema de movimiento

**Duraciones**
- Elementos pequeños (botones, chips, iconos): 200–300 ms
- Tarjetas, bloques de texto, imágenes: 500–700 ms
- Héroes y titulares grandes: 700–1000 ms
- Nunca más de 1.2 s para una entrada. Si se siente lento, es lento.

**Easing (curvas recomendadas)**
- Entrada general: `cubic-bezier(0.22, 1, 0.36, 1)` (ease-out expresivo)
- Entrada enfática: `cubic-bezier(0.16, 1, 0.3, 1)`
- Entrada juguetona: spring con stiffness ~260, damping ~20
- Evitar `linear` y `ease-in` para entradas: se sienten rígidos o lentos al final.

**Stagger (escalonado)**
- Listas y grids: 60–100 ms entre elementos
- Máximo 8–10 elementos escalonados; el resto aparece junto para no hacer esperar al usuario
- Escalonar siempre desde el elemento más importante hacia el secundario

**Reglas de rendimiento (no negociables)**
- Anima solo `transform` y `opacity`. Evita animar `top`, `left`, `width`, `height`, `margin` o `box-shadow` pesado.
- Usa `will-change` solo durante la animación, no permanentemente.
- Para blur, usa valores pequeños (4–12px) y solo en elementos pocos.
- En listas largas, usa IntersectionObserver para animar al entrar en pantalla, no todo al cargar.
- Una animación de entrada se ejecuta **una vez**. No la repitas en cada render de React sin control.

**Accesibilidad (no negociable)**
- Web: envuelve las animaciones en `@media (prefers-reduced-motion: no-preference)` o reduce a un simple fade sin desplazamiento.
- Móvil: revisa la preferencia del sistema (reducir movimiento en iOS, animaciones del sistema en Android) y ofrece un fallback con fade.
- El contenido debe ser visible aunque la animación no corra (no dejes elementos con `opacity: 0` sin salida si JS falla).

## Patrones base

Los fragmentos de código completos están en los archivos de referencia. Lee el que corresponda al entorno:

- **Web (CSS, Tailwind, JS vanilla, IntersectionObserver)**: lee `references/web.md`
- **React y Framer Motion**: lee `references/react.md`
- **Apps móviles (Android Compose, SwiftUI, Flutter, React Native)**: lee `references/mobile.md`

Patrones que siempre debes poder construir:
- Fade + slide up (base de casi todo)
- Blur-in (desenfoque que se disuelve, estilo Elegante)
- Scale-in (estilo Dinámico)
- Máscara de texto que sube (estilo Revelado)
- Stagger de lista o grid
- Reveal al hacer scroll (una sola vez)

## Qué evitar

- Animar demasiados elementos a la vez (la pantalla se siente caótica).
- Entradas de más de 1 segundo en contenido que el usuario necesita leer ya.
- Mezclar tres o cuatro estilos distintos en la misma página.
- Efectos que tapan contenido o bloquean clics mientras corren.
- Usar bibliotecas pesadas para un efecto que se resuelve con CSS en 20 líneas.

## Formato de entrega

- Código completo y listo para pegar, con comentarios breves en español.
- Una constante o variable para cambiar duración y distancia (por ejemplo `--dur`, `--dist`, `--stagger`).
- Explicación corta (3–5 líneas): estilo elegido, por qué, y cómo ajustarlo.
- Si el usuario pidió una app, indica en qué archivo o pantalla va.
