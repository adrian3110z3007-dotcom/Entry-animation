# Animaciones de entrada en web

## Tabla de contenidos
1. Variables base
2. Fade + slide up (base)
3. Blur-in (Elegante)
4. Scale-in (Dinámico)
5. Máscara de texto (Revelado)
6. Stagger de lista
7. Reveal al hacer scroll
8. Juguetón (spring con overshoot)

## 1. Variables base

```css
:root {
  --dur: 700ms;                                  /* duración principal */
  --ease: cubic-bezier(0.22, 1, 0.36, 1);       /* ease-out expresivo */
  --dist: 24px;                                  /* distancia de desplazamiento */
  --stagger: 80ms;                               /* retardo entre elementos */
}
```

## 2. Fade + slide up (base)

```css
.enter {
  opacity: 0;
  transform: translateY(var(--dist));
  animation: enter-up var(--dur) var(--ease) forwards;
}

@keyframes enter-up {
  to { opacity: 1; transform: translateY(0); }
}
```

```html
<h1 class="enter">Hola</h1>
<p class="enter" style="animation-delay: 120ms">Subtítulo</p>
```

## 3. Blur-in (estilo Elegante)

```css
.blur-in {
  opacity: 0;
  filter: blur(10px);
  transform: translateY(var(--dist));
  animation: blur-in var(--dur) var(--ease) forwards;
}

@keyframes blur-in {
  to { opacity: 1; filter: blur(0); transform: translateY(0); }
}
```

Nota: `filter: blur` es costoso en elementos grandes. Úsalo en titulares y tarjetas, no en fondos de pantalla completa.

## 4. Scale-in (estilo Dinámico)

```css
.scale-in {
  opacity: 0;
  transform: scale(0.9);
  animation: scale-in 600ms var(--ease) forwards;
}

@keyframes scale-in {
  to { opacity: 1; transform: scale(1); }
}
```

## 5. Máscara de texto (estilo Revelado)

```css
.reveal-mask {
  overflow: hidden;
  display: block;
}

.reveal-mask > span {
  display: inline-block;
  transform: translateY(110%);
  animation: mask-up 900ms var(--ease) forwards;
}

@keyframes mask-up {
  to { transform: translateY(0); }
}
```

```html
<h1 class="reveal-mask"><span>Diseño que se siente</span></h1>
```

Para varias líneas, envuelve cada línea en su propio `.reveal-mask` y escalona con `animation-delay`.

## 6. Stagger de lista

```css
.stagger > * {
  opacity: 0;
  transform: translateY(var(--dist));
  animation: enter-up var(--dur) var(--ease) forwards;
}

.stagger > *:nth-child(1) { animation-delay: calc(var(--stagger) * 0); }
.stagger > *:nth-child(2) { animation-delay: calc(var(--stagger) * 1); }
.stagger > *:nth-child(3) { animation-delay: calc(var(--stagger) * 2); }
.stagger > *:nth-child(4) { animation-delay: calc(var(--stagger) * 3); }
.stagger > *:nth-child(5) { animation-delay: calc(var(--stagger) * 4); }
.stagger > *:nth-child(6) { animation-delay: calc(var(--stagger) * 5); }
.stagger > *:nth-child(n+7) { animation-delay: calc(var(--stagger) * 6); }
```

Alternativa con una sola regla usando una variable por elemento:

```html
<ul class="stagger">
  <li style="--i:0">Uno</li>
  <li style="--i:1">Dos</li>
  <li style="--i:2">Tres</li>
</ul>
```

```css
.stagger-var > * { animation-delay: calc(var(--i, 0) * var(--stagger)); }
```

## 7. Reveal al hacer scroll (una sola vez)

```html
<section class="reveal">Contenido</section>
```

```css
.reveal {
  opacity: 0;
  transform: translateY(var(--dist));
  transition: opacity var(--dur) var(--ease), transform var(--dur) var(--ease);
}

.reveal.is-visible {
  opacity: 1;
  transform: translateY(0);
}

@media (prefers-reduced-motion: reduce) {
  .reveal { transform: none; transition: opacity 300ms linear; }
}
```

```js
const io = new IntersectionObserver((entries) => {
  for (const entry of entries) {
    if (entry.isIntersecting) {
      entry.target.classList.add('is-visible');
      io.unobserve(entry.target); // solo una vez
    }
  }
}, { threshold: 0.15 });

document.querySelectorAll('.reveal').forEach((el) => io.observe(el));
```

## 8. Juguetón (overshoot)

```css
.bounce-in {
  opacity: 0;
  transform: scale(0.6) rotate(-4deg);
  animation: bounce-in 700ms cubic-bezier(0.34, 1.56, 0.64, 1) forwards;
}

@keyframes bounce-in {
  to { opacity: 1; transform: scale(1) rotate(0); }
}
```

## Accesibilidad: envoltura obligatoria

Envuelve las animaciones decorativas así:

```css
@media (prefers-reduced-motion: no-preference) {
  .enter, .blur-in, .scale-in, .reveal-mask > span, .stagger > *, .bounce-in {
    /* las reglas de animación van aquí o ya están aplicadas */
  }
}

@media (prefers-reduced-motion: reduce) {
  .enter, .blur-in, .scale-in, .reveal-mask > span, .stagger > *, .bounce-in {
    animation: fade-only 300ms linear forwards;
    transform: none;
    filter: none;
  }
}

@keyframes fade-only { from { opacity: 0; } to { opacity: 1; } }
```

## Tailwind

Si el proyecto usa Tailwind, define las animaciones en `tailwind.config`:

```js
// tailwind.config.js
module.exports = {
  theme: {
    extend: {
      transitionTimingFunction: { expo: 'cubic-bezier(0.22, 1, 0.36, 1)' },
      keyframes: {
        'enter-up': {
          from: { opacity: '0', transform: 'translateY(24px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
      },
      animation: {
        'enter-up': 'enter-up 700ms cubic-bezier(0.22,1,0.36,1) both',
      },
    },
  },
};
```

Uso: `<h1 class="animate-enter-up">Hola</h1>`
